// File: TestMenu.java
// Small non-interactive runner to print the restaurant menu for quick checks
public class TestMenu {
    public static void main(String[] args) {
        Restaurant r = new Restaurant();
        r.displayMenu();
    }
}
